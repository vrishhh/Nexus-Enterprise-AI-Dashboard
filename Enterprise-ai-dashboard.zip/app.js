// Data structures
const businessData = {
  finance: {
    revenue_daily: 15000000,
    revenue_target: 14000000,
    gross_margin_percent: 42,
    operating_expenses: 8000000,
    net_profit_margin: 8.5,
    current_ratio: 1.85,
    return_on_assets: 12.3,
    cash_on_hand: 45000000
  },
  supply_chain: {
    otif_percent: 94.5,
    average_fulfillment_days: 3.2,
    inventory_turnover: 5.2,
    stock_cover_days: 25,
    warehouse_regions: [
      { name: 'North', inventory_units: 125000, utilization_percent: 78 },
      { name: 'South', inventory_units: 98000, utilization_percent: 82 },
      { name: 'East', inventory_units: 87000, utilization_percent: 71 },
      { name: 'West', inventory_units: 110000, utilization_percent: 85 }
    ]
  },
  marketing: {
    total_spend: 12000000,
    online_spend: 4800000,
    instore_spend: 4200000,
    mobile_spend: 3000000,
    total_conversions: 45000,
    roi_percent: 285,
    customer_acquisition_cost: 267,
    ctr_percent: 3.8
  },
  operations: {
    oee_percent: 78.5,
    oee_target: 82,
    scrap_rate_percent: 1.8,
    first_pass_yield: 96.2,
    defect_rate_ppm: 450,
    capacity_utilization: 82,
    production_units_target: 5000,
    production_units_actual: 4100
  }
};

const financeTrends = [
  { day: 1, revenue: 14200000, target: 14000000, expense: 7800000 },
  { day: 2, revenue: 14500000, target: 14000000, expense: 7900000 },
  { day: 3, revenue: 14800000, target: 14000000, expense: 8000000 },
  { day: 4, revenue: 15100000, target: 14000000, expense: 8100000 },
  { day: 5, revenue: 15300000, target: 14000000, expense: 8050000 },
  { day: 6, revenue: 15150000, target: 14000000, expense: 7950000 },
  { day: 7, revenue: 15000000, target: 14000000, expense: 8000000 }
];

const campaigns = [
  { name: 'Diwali Mega Sale', channel: 'Online', spend: 2400000, conversions: 18000, roi: 320 },
  { name: 'Store Activation', channel: 'In-Store', spend: 2100000, conversions: 12000, roi: 240 },
  { name: 'Mobile App Push', channel: 'Mobile App', spend: 1500000, conversions: 15000, roi: 380 }
];

const aiRecommendations = {
  finance: [
    'Increase working capital by ₹5 Cr for Q4 growth - projected +8% revenue',
    'Optimize supplier payment terms to improve cash flow by ₹3 Cr',
    'Reduce COGS by 2% through supplier consolidation'
  ],
  supply_chain: [
    'Increase South region inventory by 20% due to high demand forecast',
    'Implement predictive maintenance for warehouse equipment - save ₹50L annually',
    'Optimize shipping routes: reduce fulfillment time by 1 day'
  ],
  marketing: [
    'Reallocate ₹50L from Online to Mobile for +18% ROI',
    'Launch seasonal campaign for East region - projected ₹5 Cr incremental revenue',
    'Increase Mobile App budget by 25% - showing 380% ROI vs 285% average'
  ],
  operations: [
    'Line 3 predictive maintenance needed - prevent ₹75L downtime',
    'Implement Six Sigma for scrap reduction: target 1% from current 1.8%',
    'Adjust production schedule: reduce setup time by 15 minutes per shift'
  ]
};

// Live counters
let liveCounters = {
  sales: 15000000,
  orders: 213,
  inventory: 420000,
  production: 4100
};

let orderPipeline = {
  pending: 12,
  shipped: 45,
  delivered: 156
};

// Chart instances
let charts = {};

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
  initNavigation();
  updateTime();
  setInterval(updateTime, 1000);
  
  // Initialize all views
  initExecutiveDashboard();
  initFinanceDashboard();
  initSupplyChainDashboard();
  initMarketingDashboard();
  initOperationsDashboard();
  
  // Start real-time updates
  setInterval(updateLiveCounters, 2500);
  setInterval(updateOrderPipeline, 3000);
  setInterval(updateFinanceChart, 3000);
  setInterval(updateMetrics, 2000);
});

// Navigation
function initNavigation() {
  const navButtons = document.querySelectorAll('.nav-btn');
  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const view = btn.getAttribute('data-view');
      switchView(view);
      
      // Update active state
      navButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });
}

function switchView(viewName) {
  const views = document.querySelectorAll('.view-container');
  views.forEach(view => {
    view.classList.remove('active');
  });
  
  const targetView = document.getElementById(`${viewName}-view`);
  if (targetView) {
    targetView.classList.add('active');
  }
}

// Time update
function updateTime() {
  const now = new Date();
  const options = { 
    weekday: 'short', 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Kolkata'
  };
  document.getElementById('currentTime').textContent = now.toLocaleString('en-IN', options);
}

// Executive Dashboard
function initExecutiveDashboard() {
  createSparklines();
  renderAIRecommendations('finance-ai', aiRecommendations.finance);
}

function createSparklines() {
  const sparkConfigs = [
    { id: 'spark-revenue', data: financeTrends.map(d => d.revenue / 10000000), color: '#1FB8CD' },
    { id: 'spark-otif', data: [93.5, 94.0, 94.2, 93.8, 94.5, 94.3, 94.5], color: '#FFC185' },
    { id: 'spark-conversions', data: [42000, 43000, 44500, 43800, 45000, 44200, 45000], color: '#B4413C' },
    { id: 'spark-production', data: [3900, 4000, 4050, 4100, 4150, 4080, 4100], color: '#5D878F' }
  ];
  
  sparkConfigs.forEach(config => {
    const canvas = document.getElementById(config.id);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    charts[config.id] = new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7'],
        datasets: [{
          data: config.data,
          borderColor: config.color,
          backgroundColor: 'transparent',
          borderWidth: 2,
          pointRadius: 0,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: false }
        },
        scales: {
          x: { display: false },
          y: { display: false }
        }
      }
    });
  });
}

// Finance Dashboard
function initFinanceDashboard() {
  createFinanceRevenueChart();
  createFinanceExpenseChart();
  createFinanceCashflowChart();
  renderAIRecommendations('finance-ai', aiRecommendations.finance);
}

function createFinanceRevenueChart() {
  const ctx = document.getElementById('finance-revenue-chart');
  if (!ctx) return;
  
  charts.financeRevenue = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
      datasets: [
        {
          label: 'Revenue',
          data: financeTrends.map(d => d.revenue / 10000000),
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          borderWidth: 3,
          tension: 0.4,
          fill: true
        },
        {
          label: 'Target',
          data: financeTrends.map(d => d.target / 10000000),
          borderColor: '#B4413C',
          borderWidth: 2,
          borderDash: [5, 5],
          tension: 0,
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: true, position: 'top' },
        tooltip: {
          callbacks: {
            label: (context) => `${context.dataset.label}: ₹${context.parsed.y.toFixed(1)} Cr`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          ticks: {
            callback: (value) => `₹${value} Cr`
          }
        }
      }
    }
  });
}

function createFinanceExpenseChart() {
  const ctx = document.getElementById('finance-expense-chart');
  if (!ctx) return;
  
  charts.financeExpense = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['COGS', 'Operating Expenses', 'Marketing Spend', 'Other'],
      datasets: [{
        data: [45, 28, 18, 9],
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5'],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right' },
        tooltip: {
          callbacks: {
            label: (context) => `${context.label}: ${context.parsed}%`
          }
        }
      }
    }
  });
}

function createFinanceCashflowChart() {
  const ctx = document.getElementById('finance-cashflow-chart');
  if (!ctx) return;
  
  charts.financeCashflow = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
      datasets: [
        {
          label: 'Conservative',
          data: [42, 45, 43, 46, 44, 47],
          backgroundColor: '#B4413C'
        },
        {
          label: 'Current',
          data: [45, 48, 47, 50, 49, 52],
          backgroundColor: '#1FB8CD'
        },
        {
          label: 'Optimistic',
          data: [48, 52, 51, 55, 54, 58],
          backgroundColor: '#5D878F'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'top' },
        tooltip: {
          callbacks: {
            label: (context) => `${context.dataset.label}: ₹${context.parsed.y} Cr`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: (value) => `₹${value} Cr`
          }
        }
      }
    }
  });
}

function updateFinanceChart() {
  if (!charts.financeRevenue) return;
  
  // Simulate new data point
  const lastRevenue = financeTrends[financeTrends.length - 1].revenue;
  const newRevenue = lastRevenue + (Math.random() - 0.5) * 500000;
  
  // Shift data (remove first, add new)
  financeTrends.shift();
  financeTrends.push({
    day: financeTrends[financeTrends.length - 1].day + 1,
    revenue: newRevenue,
    target: 14000000,
    expense: 8000000
  });
  
  // Update chart
  charts.financeRevenue.data.datasets[0].data = financeTrends.map(d => d.revenue / 10000000);
  charts.financeRevenue.update('none');
}

// Supply Chain Dashboard
function initSupplyChainDashboard() {
  createSupplyInventoryChart();
  renderAIRecommendations('supply-ai', aiRecommendations.supply_chain);
}

function createSupplyInventoryChart() {
  const ctx = document.getElementById('supply-inventory-chart');
  if (!ctx) return;
  
  const regions = businessData.supply_chain.warehouse_regions;
  
  charts.supplyInventory = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: regions.map(r => r.name),
      datasets: [{
        label: 'Inventory (K units)',
        data: regions.map(r => r.inventory_units / 1000),
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#5D878F'],
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: (context) => `${context.parsed.y}K units (${regions[context.dataIndex].utilization_percent}% utilized)`
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: (value) => `${value}K`
          }
        }
      }
    }
  });
}

// Marketing Dashboard
function initMarketingDashboard() {
  renderCampaignTable();
  createMarketingBudgetChart();
  createMarketingEngagementChart();
  renderAIRecommendations('marketing-ai', aiRecommendations.marketing);
}

function renderCampaignTable() {
  const tbody = document.getElementById('campaign-table-body');
  if (!tbody) return;
  
  tbody.innerHTML = campaigns.map(campaign => `
    <tr>
      <td><strong>${campaign.name}</strong></td>
      <td>${campaign.channel}</td>
      <td>₹${(campaign.spend / 100000).toFixed(1)}L</td>
      <td>${campaign.conversions.toLocaleString('en-IN')}</td>
      <td><strong style="color: var(--color-success)">${campaign.roi}%</strong></td>
      <td><span class="badge badge-success">Active</span></td>
    </tr>
  `).join('');
}

function createMarketingBudgetChart() {
  const ctx = document.getElementById('marketing-budget-chart');
  if (!ctx) return;
  
  charts.marketingBudget = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Online', 'In-Store', 'Mobile App'],
      datasets: [{
        data: [40, 35, 25],
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right' },
        tooltip: {
          callbacks: {
            label: (context) => `${context.label}: ${context.parsed}%`
          }
        }
      }
    }
  });
}

function createMarketingEngagementChart() {
  const ctx = document.getElementById('marketing-engagement-chart');
  if (!ctx) return;
  
  charts.marketingEngagement = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Online', 'In-Store', 'Mobile App'],
      datasets: [{
        label: 'Engagement Score',
        data: [75, 68, 82],
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
        borderRadius: 8
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
          beginAtZero: true,
          max: 100
        }
      }
    }
  });
}

// Operations Dashboard
function initOperationsDashboard() {
  createOperationsProductionChart();
  createOperationsDowntimeChart();
  createOperationsCapacityChart();
  renderAIRecommendations('operations-ai', aiRecommendations.operations);
  updateOEEGauge(businessData.operations.oee_percent);
}

function createOperationsProductionChart() {
  const ctx = document.getElementById('operations-production-chart');
  if (!ctx) return;
  
  charts.operationsProduction = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
      datasets: [
        {
          label: 'Target',
          data: [5000, 5000, 5000, 5000, 5000, 5000, 5000],
          borderColor: '#B4413C',
          borderWidth: 2,
          borderDash: [5, 5],
          tension: 0,
          fill: false
        },
        {
          label: 'Actual',
          data: [3900, 4000, 4050, 4100, 4150, 4080, 4100],
          borderColor: '#1FB8CD',
          backgroundColor: 'rgba(31, 184, 205, 0.1)',
          borderWidth: 3,
          tension: 0.4,
          fill: true
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'top' }
      },
      scales: {
        y: {
          beginAtZero: false,
          min: 3500
        }
      }
    }
  });
}

function createOperationsDowntimeChart() {
  const ctx = document.getElementById('operations-downtime-chart');
  if (!ctx) return;
  
  charts.operationsDowntime = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Maintenance', 'Breakdown', 'Setup', 'Other'],
      datasets: [{
        data: [35, 25, 30, 10],
        backgroundColor: ['#1FB8CD', '#B4413C', '#FFC185', '#ECEBD5'],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'right' },
        tooltip: {
          callbacks: {
            label: (context) => `${context.label}: ${context.parsed}%`
          }
        }
      }
    }
  });
}

function createOperationsCapacityChart() {
  const ctx = document.getElementById('operations-capacity-chart');
  if (!ctx) return;
  
  charts.operationsCapacity = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Line 1', 'Line 2', 'Line 3', 'Line 4', 'Line 5'],
      datasets: [{
        label: 'Capacity Utilization (%)',
        data: [85, 78, 72, 88, 82],
        backgroundColor: ['#1FB8CD', '#1FB8CD', '#B4413C', '#1FB8CD', '#1FB8CD'],
        borderRadius: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
          ticks: {
            callback: (value) => `${value}%`
          }
        }
      }
    }
  });
}

function updateOEEGauge(value) {
  const gaugeFill = document.getElementById('oee-gauge-fill');
  const valueText = document.getElementById('oee-value');
  
  if (!gaugeFill || !valueText) return;
  
  // Calculate stroke-dashoffset (251.2 is the path length, 0-100% maps to 251.2-0)
  const offset = 251.2 - (value / 100) * 251.2;
  gaugeFill.setAttribute('stroke-dashoffset', offset);
  valueText.textContent = `${value.toFixed(1)}%`;
}

// Helper functions
function renderAIRecommendations(elementId, recommendations) {
  const container = document.getElementById(elementId);
  if (!container) return;
  
  container.innerHTML = recommendations.map(rec => 
    `<div class="ai-rec-item">${rec}</div>`
  ).join('');
}

function updateLiveCounters() {
  // Simulate real-time updates
  liveCounters.sales += Math.floor(Math.random() * 50000) + 10000;
  liveCounters.orders += Math.floor(Math.random() * 3);
  liveCounters.inventory += Math.floor(Math.random() * 200) - 100;
  liveCounters.production += Math.floor(Math.random() * 10);
  
  // Update UI with animation
  animateValue('live-sales', liveCounters.sales, (val) => `₹${val.toLocaleString('en-IN')}`);
  animateValue('live-orders', liveCounters.orders);
  animateValue('live-inventory', liveCounters.inventory, (val) => val.toLocaleString('en-IN'));
  animateValue('live-production', liveCounters.production, (val) => val.toLocaleString('en-IN'));
}

function updateOrderPipeline() {
  // Simulate order flow
  if (Math.random() > 0.5) {
    orderPipeline.pending += Math.floor(Math.random() * 2);
  }
  if (Math.random() > 0.6) {
    orderPipeline.pending = Math.max(0, orderPipeline.pending - 1);
    orderPipeline.shipped += 1;
  }
  if (Math.random() > 0.7) {
    orderPipeline.shipped = Math.max(0, orderPipeline.shipped - 1);
    orderPipeline.delivered += 1;
  }
  
  animateValue('orders-pending', orderPipeline.pending);
  animateValue('orders-shipped', orderPipeline.shipped);
  animateValue('orders-delivered', orderPipeline.delivered);
}

function updateMetrics() {
  // Simulate small fluctuations in metrics
  const oeeChange = (Math.random() - 0.5) * 0.2;
  businessData.operations.oee_percent = Math.max(75, Math.min(82, businessData.operations.oee_percent + oeeChange));
  updateOEEGauge(businessData.operations.oee_percent);
  
  // Update OTIF
  const otifChange = (Math.random() - 0.5) * 0.1;
  businessData.supply_chain.otif_percent = Math.max(93, Math.min(96, businessData.supply_chain.otif_percent + otifChange));
  const otifElem = document.getElementById('sc-otif');
  if (otifElem) {
    otifElem.textContent = `${businessData.supply_chain.otif_percent.toFixed(1)}%`;
  }
}

function animateValue(elementId, targetValue, formatter = null) {
  const element = document.getElementById(elementId);
  if (!element) return;
  
  const currentText = element.textContent;
  const currentValue = parseInt(currentText.replace(/[^0-9]/g, '')) || 0;
  
  if (currentValue === targetValue) return;
  
  const duration = 500;
  const startTime = performance.now();
  const difference = targetValue - currentValue;
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const value = Math.floor(currentValue + difference * progress);
    
    element.textContent = formatter ? formatter(value) : value;
    
    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }
  
  requestAnimationFrame(update);
}

// Format currency
function formatCurrency(value) {
  if (value >= 10000000) {
    return `₹${(value / 10000000).toFixed(1)} Cr`;
  } else if (value >= 100000) {
    return `₹${(value / 100000).toFixed(1)}L`;
  }
  return `₹${value.toLocaleString('en-IN')}`;
}